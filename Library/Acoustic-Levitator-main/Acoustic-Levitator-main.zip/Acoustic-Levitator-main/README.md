# Acoustic-Levitator
中文参考链接：https://www.sohu.com/a/253213923_648798<br>
英文参考链接：https://www.instructables.com/Acoustic-Levitator/<br>
原理解析：https://aip.scitation.org/doi/full/10.1063/1.4989995<br>
